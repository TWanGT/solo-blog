title: mysql 常用函数整理
date: '2019-11-15 17:46:41'
updated: '2019-11-15 17:46:41'
tags: [mysql语法]
permalink: /articles/2019/11/15/1573811201105.html
---
![](https://img.hacpai.com/bing/20190706.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

时间函数
	获取当前日期

	select now();

string 转 date

	str_to_date(str, format)
	如 STR_TO_DATE("2016-09-30","%Y-%m-%d")
date 转  string
	time_format（str, format）同理str_to_date
日期加减
	日期加上时间间隔

	select date_add(rq, interval 1 day); 
	select date_add(rq, interval 1 hour); 
	select date_add(rq, interval 1 minute);
	select date_add(rq, interval 1 second);
	select date_add(rq, interval 1 microsecond);
	select date_add(rq, interval 1 week);
	select date_add(rq, interval 1 month);
	select date_add(rq, interval 1 quarter);
	select date_add(rq, interval 1 year);