title: mongodb 聚合函数(管道查询)
date: '2019-08-01 13:59:00'
updated: '2019-08-02 13:36:32'
tags: [mongodb, 数据库]
permalink: /articles/2019/08/01/1564639140699.html
---
# mongodb 聚合函数(管道查询)

> 管道在Unix和Linux中一般用于将当前命令的输出结果作为下一个命令的参数。

`MongoDB`的聚合管道将`MongoDB文档`在一个管道处理完毕后将结果传递给下一个管道处理。就是类似流水线生产一样, 管道操作是可以重复的。
表达式：处理输入文档并输出。表达式是无状态的，只能用于计算当前聚合管道的文档，不能处理其它的文档。

这里我们介绍一下聚合框架中常用的几个操作：
* `$project`：修改输入文档的结构。可以用来重命名、增加或删除域，也可以用于创建计算结果以及嵌套文档。
* `$match`：用于过滤数据，只输出符合条件的文档。$match使用MongoDB的标准查询操作。
* `$limit`：用来限制MongoDB聚合管道返回的文档数。
* `$skip`：在聚合管道中跳过指定数量的文档，并返回余下的文档。
* `$unwind`：将文档中的某一个数组类型字段拆分成多条，每条包含数组中的一个值。
* `$group`：将集合中的文档分组，可用于统计结果。
* ` $sort`：将输入文档排序后输出。
* `$geoNear`：输出接近某一地理位置的有序文档。

# 示例

## 格式
```mongodb
db.xxx.aggregate(
    { $上面的操作符 : {
        _id : 0 ,
        title : 1 ,
        author : 1
    }});
```

## 查询示例
>注意: 同样的操作符以及条件, 不同的排列顺序对查询结果会有影响

### 先分组再排序
1.  先`in`查询在这几个`personId`里面的
2. 按`personId`分组, 并取出第一个`evaluationTime`
3. 按`evaluationTime`排列数据
```mongodb
db.personalHealthRiskEvaluation.aggregate(
[
{$match: {personId: {$in: ["p180123112810018", "p160307185810006", "p180224165910065"]}}},
{$group: {_id: "$personId", "evaluationTime": {$first: "$evaluationTime"}}},
{$sort:{"evaluationTime":-1}}
]);
```

查询结果
![2018112913424929.png](https://img.hacpai.com/file/2019/08/2018112913424929-01ddee67.png)
![在这里插入图片描述](https://img-blog.csdnimg.cn/2018112913424929.png)
### 先排序再分组
1.  先`in`查询在这几个`personId`里面的
2. 按`evaluationTime`排列数据
3. 按`personId`分组, 并取出第一个`evaluationTime`
```mongodb
db.personalHealthRiskEvaluation.aggregate(
[
{$match: {personId: {$in: ["p180123112810018", "p160307185810006", "p180224165910065"]}}},
{$sort:{"evaluationTime":-1}},
{$group: {_id: "$personId", "evaluationTime": {$first: "$evaluationTime"}}}
]);
```

查询结果
![20181129134328622.png](https://img.hacpai.com/file/2019/08/20181129134328622-3ef43df5.png)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20181129134328622.png)