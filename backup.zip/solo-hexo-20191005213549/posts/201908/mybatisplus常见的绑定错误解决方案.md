title: mybatis-plus 常见的绑定错误解决方案
date: '2019-08-09 15:08:35'
updated: '2019-08-09 15:16:21'
tags: [java, 数据库]
permalink: /articles/2019/08/09/1565334515244.html
---
# mybatis-plus 常见的绑定错误解决方案

  

> 比较长见到的几个绑定错误:

>  * org.apache.ibatis.binding.BindingException: Invalid bound statement (not found)

>  * Result Maps collection already contains value for xxx

  

## org.apache.ibatis.binding.BindingException: Invalid bound statement (not found)

这个异常出现的原因有蛮多的, 不过最终都是一个最本质的原因就是映射关系不对或者没找到

### 1. xml 文件配置问题

`xml`中注意三个地方

1.  `namespace`: 是否正确指向的 `mapper` 文件`<mapper namespace="com.wang.mapper.mysql.xxxMapper">`

2.  `resultMap`: 是否正确指向你的数据库实体类 `<resultMap id="BaseResultMap" type="com.wang.entity.xxx">`

3.  `parameterType`: 每个方法中的 `parameterType` 是否都指向对应的参数实体

  

### 2. application 的配置问题

`application.properties` 中加上 `mapper` 以及 `xml` 的路径配置

  

*  `properties` 版本

```

mybatis-plus.mapper-locations=classpath:/mapper/mysql/*.xml

mybatis-plus.type-aliases-package=com.wang.mapper.mysql

```

*  `yaml` 版本

```yaml

mybatis-plus:

mapper-locations: classpath:/mapper/mysql/*.xml

type-aliases-package: com.wang.mapper.mysql

  

```

  

### 3. mybatis-plus mapper扫描配置问题

#### 方案一:

可以新建一个 `mybatis_plus.java` 类来专门配置扫描地址

类上加上注解

```

@Configuration

@MapperScan(value = {"com.wang.a.mapper.mysql", "com.wang.b.mapper.mysql"})

```

  

#### 方案二:

  

在系统启动类上加上注解

```

@MapperScan(value = {"com.wang.a.mapper.mysql", "com.wang.b.mapper.mysql"})

```

> 注意: `@MapperScan` 这个注解要在 `@SpringBootApplication` 上面, 否者可能会无效

  

#### 方案三:

在每个 `mapper` 文件上加上 `@mapper` 扫描注解

  

### 4. 是否使用功能的mybatis-plus

这个是比较尴尬的一个问题, 我把一个没用 `mybatis-plus` 的项目加入 `mybatis-plus`, 然后搞了老半天都没搞定, 后面发现以前是用自己的驱动类做的数据库连接, `mybatis-plus` 是基于 `spring` 的那套数据库连接方式(配置中的数据库配置以 `spring.xxx`开头的)

  

## Result Maps collection already contains value for xxx

这个错误比较简单, 只要检查下 `xxxMapper.xml` 文件的内容就好了

主要是 `resultMap` 或者是方法有重名导致的

使用 `mybatis` 代码生成工具多次的话容易导致 `xml` 中有重复的 `ResultMap` 或方法

  
  

![IP签名](https://tool.lu/netcard/)~~~~