title: 使用官网镜像搭建私有docker仓库
date: '2019-07-31 20:43:13'
updated: '2019-07-31 20:43:13'
tags: [docker, 容器]
permalink: /articles/2019/07/31/1564576993708.html
---
# 使用官网镜像搭建私有docker仓库

`docker` 有个官方仓库, [docker hub](https://www.docker.com/products/docker-hub)但是在数量上有所限制(私有项目数), 所以我们搭建个私有库方便日常的学习和工作 


## 安装 `docker-registry`
### 寻找仓库
按照惯例, 先 `search` 一波
```
docker search registry
```
结果如下:
![docker search registry结果图](https://img.hacpai.com/file/2019/07/image-fa24985a.png)

可以看到第一个就是我们想要的 `docker` 仓库

### 拉取镜像
使用如下命令拉取:
```
docker pull registry
```

结果如下
```shell
wang@wang-Parallels-Virtual-Platform:~/nginx/log$ docker pull registry
Using default tag: latest
latest: Pulling from library/registry
c87736221ed0: Pull complete 
1cc8e0bb44df: Pull complete 
54d33bcb37f5: Pull complete 
e8afc091c171: Pull complete 
b4541f6d3db6: Pull complete 
Digest: sha256:8004747f1e8cd820a148fb7499d71a76d45ff66bac6a29129bfdbfdc0154d146
Status: Downloaded newer image for registry:latest
```

这时我们的本地镜像库就多了个 `registry` 的镜像
```
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
registry            latest              f32a97de94e1        4 months ago        25.8MB
```

## 运行 `docker-registry`
### 创建容器并启动
使用 `docker run` 命令启动镜像, 暴露 `5000` 端口
命令如下: 
```shell
docker run -d -p 5000:5000 \
	--restart=always \
	--name registry registry
```

### 检查运行情况
使用命令查看进程是否运行中
```
docker ps
```
看到如下结果就表示本地是有库搭建好了
```
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                                              NAMES
2f6b67d008f6        registry            "/entrypoint.sh /etc…"   4 seconds ago       Up 3 seconds        0.0.0.0:5000->5000/tcp                             registry
```
