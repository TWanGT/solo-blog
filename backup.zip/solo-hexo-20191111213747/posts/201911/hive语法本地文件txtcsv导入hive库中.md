title: hive语法本地文件（txt，csv）导入hive库中
date: '2019-11-09 15:48:21'
updated: '2019-11-09 15:48:21'
tags: [hive]
permalink: /articles/2019/11/09/1573285701073.html
---
第一步：
建表语句
create table IF NOT EXISTS raw.t_zichan(

zcdm STRING COMMENT '资产代码',

zcmc STRING COMMENT '资产名称'

)row format delimited fields terminated by ',' stored as textfile
分隔符语句在建表之后一定加上，分隔符以本地文件中的分隔符为主~~~~

第二步：
上传文件到hive库所在linux目录下，如
/sunmnet/etl/model/static/zichan.txt

第三步：
进入hive
hive;

第四步：
执行load语法（记住结尾要加;号）
LOAD DATA LOCAL INPATH '/sunmnet/etl/model/static/zichan.txt'  INTO TABLE raw_xzgc.t_zichan;

第五步：
完成

