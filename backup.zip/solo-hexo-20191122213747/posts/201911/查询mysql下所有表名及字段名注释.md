title: 查询mysql下所有表名及字段名注释
date: '2019-11-15 17:47:41'
updated: '2019-11-15 17:47:41'
tags: [mysql]
permalink: /articles/2019/11/15/1573811261096.html
---
SELECT

t.TABLE_NAME,

t.TABLE_COMMENT,

c.COLUMN_NAME,

c.COLUMN_TYPE,

c.COLUMN_COMMENT

FROM

information_schema. TABLES t,

INFORMATION_SCHEMA. COLUMNS c

WHERE

c.TABLE_NAME = t.TABLE_NAME

AND t.`TABLE_SCHEMA` = 'bigdata_tongji'