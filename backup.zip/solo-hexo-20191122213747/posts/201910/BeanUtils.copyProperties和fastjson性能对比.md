title: BeanUtils.copyProperties 和 fastjson 性能对比
date: '2019-10-08 17:20:23'
updated: '2019-11-21 18:36:06'
tags: [java]
permalink: /articles/2019/10/08/1570526423397.html
---
# BeanUtils.copyProperties 和 fastjson 性能对比

## 声明
> 测试方法非严格方式, 测试结果以及结论仅供参考!
> 测试方法非严格方式, 测试结果以及结论仅供参考!
> 测试方法非严格方式, 测试结果以及结论仅供参考!

#### 运行环境
* cpu: i5-8400(6c 6t 3.8主频)
* 内存: 16G(2666频率)*2
* 系统: Mac OS 10.14.6 (18G95)
* java环境: jdk1.8.0_171

#### 测试样本
用json输出大概是7kb

#### 对比测试方法
`BeanUtils.copyProperties`有的字段无法正确复制, 我们用`json`序列化(兼容性好)来进行对比测试
`json` 工具使用的是阿里 `fastJson`

> 由于测试循环中加入了一个检测是否新建对象的逻辑(防止程序自动优化出现假的字段拷贝), 所以实际执行时间会比给出的测试耗时要稍微短一点

## 第一轮测试(10次循环)

#### 测试次数
10次循环

#### 测试结果
测试结果相差无几, 有时 `BeanUtils` 快点, 有时 `json` 的方式快点, 应该是样本量太小导致成绩受系统波动的影响太大
![fa696c5fceccd831ffbc49bf4f9fdb88.png](blob:http://twangt.wang:8080/0a305081-8209-4ec2-a71f-93a2e9f994e8)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191008172238646.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM0MjA4ODQ0,size_16,color_FFFFFF,t_70)

## 第二轮测试(100次循环)

#### 测试次数
100次循环

#### 测试结果
序号|方式|耗时
---|---|---
1|BeanUtils|4ms
1|json|41ms
2|BeanUtils|4ms
2|json|47ms
3|BeanUtils|1ms
3|json|13ms
4|BeanUtils|1ms
4|json|11ms

已经体现出一些差距了


## 第三轮测试(1000次循环)

#### 测试次数
1000次循环

#### 测试结果
序号|方式|耗时
| --- | --- | --- |
1|BeanUtils|8ms
1|json|110ms
2|BeanUtils|3ms
2|json|61ms
3|BeanUtils|2ms
3|json|67ms
4|BeanUtils|3ms
4|json|67ms

1000次循环的轻度下大约是20倍的性能差距, 不过波动还是比较大, 我们继续增加次数

## 第四轮测试(10000次循环)

#### 测试次数
10000次循环

#### 测试结果
序号|方式|耗时
| --- | --- | --- |
1|BeanUtils|33ms
1|json|638ms
2|BeanUtils|33ms
2|json|643ms
3|BeanUtils|25ms
3|json|621ms
4|BeanUtils|31ms
4|json|630ms


还是大约是20倍左右的性能差距, 第三组蹦跶到快25倍了

## 第五轮测试(200000次循环)

#### 测试次数
200000次循环

#### 测试结果
![](https://raw.githubusercontent.com/TWanGT/pic/master/20191121182239.png)
![](https://raw.githubusercontent.com/TWanGT/pic/master/20191121182226.png)
![](https://raw.githubusercontent.com/TWanGT/pic/master/20191121182213.png)
![](https://raw.githubusercontent.com/TWanGT/pic/master/20191121182206.png)


依旧是20倍左右的差距, 循环200000次但新建对象不是预期的200000而总是少10个左右...

## 结论
使用 `BeanUtils` 自动复制字段, 性能大概是 `json序列化`  方式复制字段的`20倍`, 不过如果对象不是十分复杂, 这个差距可以接受, 性能不敏感的话可以考虑使用 `json序列化` 的方式进行字段复制

## 源码
测试关键逻辑源码
```java
final int testNums = 200000;
    Map<String, String> map = Maps.newHashMap("key", "value");
    long startTime1 = nowMillis();
    int num = testNums;
    int count = 0;
    while (num > 0) {
        num--;
        count++;
        Page<EvaluationUserWithResult> tempReturnPage = new Page<>();
        BeanUtils.copyProperties(evaluationUserPage, tempReturnPage);
        map.put(tempReturnPage.hashCode() + "", tempReturnPage.hashCode() +"");

    }
    log.error("beanutil循环{}次, 新建临时对象{}个, 用时{}", count, map.size()-1, DateTimeStyle.duration(startTime1));


    long startTime2 = nowMillis();
    num = testNums;
    map = Maps.newHashMap("key", "value");
    count = 0;
    while (num > 0) {
        num--;
        count++;
        Page<EvaluationUserWithResult> tempReturnPage = new Page<>();
        tempReturnPage = JSON.parseObject(JSON.toJSONString(evaluationUserPage), tempReturnPage.getClass());
        map.put(tempReturnPage.hashCode() + "", tempReturnPage.hashCode() +"");
    }
    log.error("json循环{}次, 新建临时对象{}个, 用时{}", count, map.size()-1, DateTimeStyle.duration(startTime2));
```

## 样本数据
```json
{
    "code": 0,
    "msg": "成功",
    "data": {
        "itemsWithResult": [
            {
                "maxProgress": 6,
                "hmoId": "CYH3211204110000",
                "medChannel": 2,
                "updateTime": 1569746589000,
                "evaluationTime": 1569746589000,
                "userName": "202",
                "itemsResult": {
                    "bc": "",
                    "op": "较高风险",
                    "dyslipemia": "高危",
                    "diab": "已患病",
                    "lungcnacer": "暂无风险",
                    "stroke": "中危人群",
                    "cvd": "较高风险",
                    "pc": "暂无风险",
                    "sportrisk": "较高风险",
                    "hbp": "高风险",
                    "疾病类型": "疾病风险程度",
                    "depression": "可能有重度抑郁倾向",
                    "obesity": "正常"
                },
                "userAge": 39,
                "evaluationId": "8a3147b08opsf878da8622525389fd26",
                "userUnit": "gryh",
                "createTime": 1569745748000,
                "medChannelDesc": "医生录入",
                "userMobile": "99300000202",
                "progress": 6,
                "personId": "test2",
                "userGender": 1,
                "id": 546,
                "evaluationKey": "PersonalHealthRiskEvaluation",
                "evaluationState": 1
            },
            {
                "maxProgress": 6,
                "hmoId": "CYH3211204110000",
                "medChannel": 2,
                "updateTime": 1569745630000,
                "evaluationTime": 1569745629000,
                "userName": "32423",
                "itemsResult": {
                    "bc": "",
                    "op": "较低风险",
                    "dyslipemia": " 低危",
                    "diab": "已患病",
                    "lungcnacer": "暂无风险",
                    "stroke": "高危人群",
                    "cvd": "中等风险",
                    "pc": "高危",
                    "sportrisk": "较高风险",
                    "hbp": "已异常",
                    "疾病类型": "疾病风险程度",
                    "depression": "可能有重度抑郁倾向",
                    "obesity": "正常"
                },
                "userAge": 39,
                "evaluationId": "833a6eac1dbss673f54f44f5c1c62d7a",
                "userUnit": "gryh",
                "createTime": 1563876718000,
                "medChannelDesc": "医生录入",
                "userMobile": "15999999999",
                "progress": 6,
                "personId": "test2",
                "userGender": 1,
                "id": 495,
                "evaluationKey": "PersonalHealthRiskEvaluation",
                "evaluationState": 1
            },
            {
                "maxProgress": 6,
                "hmoId": "CYH3211204110000",
                "medChannel": 2,
                "updateTime": 1563876694000,
                "evaluationTime": 1563876693000,
                "userName": "测试",
                "itemsResult": {
                    "bc": "",
                    "op": "较低风险",
                    "dyslipemia": " 低危",
                    "diab": "高风险",
                    "lungcnacer": " 低危",
                    "stroke": "低危人群",
                    "cvd": "较低风险",
                    "pc": "高危",
                    "sportrisk": "中等风险",
                    "hbp": "中等风险",
                    "疾病类型": "疾病风险程度",
                    "depression": "可能有中重度抑郁倾向",
                    "obesity": "正常"
                },
                "userAge": 39,
                "evaluationId": "2a9ggg508e47412fc5cc092d7ae7c05e",
                "userUnit": "gryh",
                "createTime": 1557737311000,
                "medChannelDesc": "医生录入",
                "userMobile": "15999930566",
                "progress": 6,
                "personId": "test1",
                "userGender": 1,
                "id": 487,
                "evaluationKey": "PersonalHealthRiskEvaluation",
                "evaluationState": 1
            },
            {
                "maxProgress": 7,
                "hmoId": "CYH3211204110000",
                "medChannel": 1,
                "updateTime": 1562763683000,
                "evaluationTime": 1557473650000,
                "userName": "测试2",
                "itemsResult": {
                    "bc": "较高风险",
                    "op": "较低风险",
                    "dyslipemia": " 低危",
                    "diab": "高风险",
                    "lungcnacer": "暂无风险",
                    "stroke": "低危人群",
                    "cvd": "高风险",
                    "pc": "",
                    "sportrisk": "较低风险",
                    "hbp": "高风险",
                    "疾病类型": "疾病风险程度",
                    "depression": "可能有中度抑郁倾向",
                    "obesity": "超重"
                },
                "userAge": 39,
                "evaluationId": "ba8cd69396f3603e6e7b27e7f77d5a4a",
                "userUnit": "gryh",
                "createTime": 1557473530000,
                "medChannelDesc": "用户填写",
                "userMobile": "手机号2",
                "progress": 7,
                "personId": "test3",
                "userGender": 2,
                "id": 483,
                "evaluationKey": "PersonalHealthRiskEvaluation",
                "evaluationState": 4
            },
            {
                "maxProgress": 6,
                "hmoId": "CYH3211204110000",
                "medChannel": 1,
                "updateTime": 1557473641000,
                "evaluationTime": 1557473641000,
                "userName": "测试2",
                "itemsResult": {
                    "bc": "",
                    "op": "较低风险",
                    "dyslipemia": " 低危",
                    "diab": "高风险",
                    "lungcnacer": "暂无风险",
                    "stroke": "低危人群",
                    "cvd": "较高风险",
                    "pc": "极高危",
                    "sportrisk": "中等风险",
                    "hbp": "高风险",
                    "疾病类型": "疾病风险程度",
                    "depression": "可能有重度抑郁倾向",
                    "obesity": "超重"
                },
                "userAge": 39,
                "evaluationId": "edf65b5a233cfd2eggf1c548374cde8f",
                "userUnit": "gryh",
                "createTime": 1557473249000,
                "medChannelDesc": "用户填写",
                "userMobile": "手机号2",
                "progress": 6,
                "personId": "test",
                "userGender": 1,
                "id": 482,
                "evaluationKey": "PersonalHealthRiskEvaluation",
                "evaluationState": 1
            }
        ],
        "pageNo": 1,
        "pageSize": 5,
        "pageCount": 3,
        "recordCount": 13
    }
}
```