title: DeskMini310 黑苹果
date: '2019-07-30 11:07:24'
updated: '2019-07-30 11:07:24'
tags: [黑苹果]
permalink: /articles/2019/07/30/1564456044182.html
---

# DeskMini310 黑苹果

## 国外的两个黑苹果论坛
https://hackintosh.com
https://www.tonymacx86.com
https://www.tonymacx86.com/threads/an-idiots-guide-to-lilu-and-its-plug-ins.260063/#Install

## 启动参数
-brcmfxbeta
brcmfx-country=US


## 装机配置
类型|型号|价格|购买渠道
-|-|-|-
cpu|i5 8400散片|1068|淘宝
主板|DeskMini 310|999|京东
机箱|主板包含|0|京东
电源|主板包含|0|京东
内存|威刚16g 2666|539|京东
内存2|威刚16g 2666|499|京东
cpu散热器|大镰刀十手8039双风扇|189|淘宝
nvme硬盘|西数黑盘sn720 500g|799|京东
wifi和蓝牙|94360cs2|115|淘宝
总共花费: 1068+999+539+499+189+799+115=4208

> 有几点说明下: 
> 1. 固态盘是1个多月前京东入手的, 然后西数黑盘不知道啥原因价格血崩了, 现在淘宝不到600就能买到了...
> 2. 这个散热器做工感觉挺精致的, 散热效果也还不错, 不过有3点比较尴尬的地方
> * 1️⃣: 双风扇超过了`DeskMini 310`的限高(只能装下面那个风扇)  更新: 可以通过扎带将另一个分散固定在机箱上
> * 2️⃣: 风扇是4pin的(理论上支持pwm调速), 但不知道为什么我无法调速(恒定在1500转左右, 不过我觉得没太大的噪音) 更新: 在系统中正确的变速了, 2200转速之下基本没声音, 待机大概1.5-1.6k转速
> * 3️⃣: 散热器稍微挡住了一套内存插槽, 调整下有机会可以兼容2条内存(`不确定`) 更新: 调整方位可以放两条内存了, 不过io挡板被顶变形了, 问题不大
> *  散热器推荐用`L9i`
> 3. 电源可以用别的类似规格的19v电源代替(或者使用pd协议的充电器, 加个usb-c转dc口的诱导转换器)
> 4. `i5 8400` 的性能已经蛮强了, 上i7或者更高感觉没必要, 主板的供电也不能很好的支撑, `8700t es` 35w的功耗也挺合适的, 有时间折腾的可以上`qn8h`那一类的测试版(工程版)的U(8700的规格 不到1k的价格)

## hackintosh 安装步骤(简介)
`hackintosh`的安装是很繁琐的, 设计到引导和驱动的各自配置和调试, 尽量选择别人安装成功并且分享出引导和驱动文件的硬件配置, 可以少折腾很多, 显卡比较舒服的是`amd rx`系列显卡(在`10.14.5`中支持显卡硬解了)
* 尽可能都选择免驱的硬件(特别是在白苹果中有使用的硬件型号)

下面是大概的一个安装步骤(只是一些主要的步骤, 省略了各种配置的过程, 如果和别人的配置一样, 一般来说可以直接用别人分享出来的设置)
1. 下载镜像
2. 制作启动U盘([clover制作参考](
https://www.sqlsec.com/2018/08/clover.html))
3. 设置bios参数(这个根据自己的主板来, 主要把`secure`那些关掉)
```
    Load UEFI Defaults
    Advanced
        Onboard HD Audio: Enabled
        USB Configuration:
            XHCI Hand-off, Enabled
        Super IO Configuration:
            Serial Port, Disabled（必须）
        Security Secure Boot:
            Disabled(by default)
    CSM打开 ，仅UEFI
```
4. 使用制作好的u盘启动并进入`clover`
5. 在`clover`中选择安装`macOS`(注意8系的核显默认不能`hdmi`输出视频, 建议用`dp`线连接, 还有`macOS`不支持`vac`输出)
6. 然后再次进入`clover`选择`macOS`就正式开始安装了(安装过程不要联网, 免得不必要的麻烦)
7. 安装后进入系统需要将引导写到硬盘中(否者需要插着u盘启动), 借助`clover configaration`软件(分别挂载硬盘efi分区和u盘efi分区, 然后将u盘的拷贝过去即可)
8. 针对声卡, 显卡, [网卡和蓝牙](
https://www.cnblogs.com/SemiconductorKING/p/7702410.html)的驱动调整
9. 修改`smbios`, 序列号等
10. 基本上就完成了一台黑苹果的制作了

## 参考文章

* [黑果小兵hackintosh教程](
    https://blog.daliansky.net/macOS-Mojave-10.14.5-18F132-official-version-with-Clover-4928-original-image.html#more)
* [deskMini310完美黑苹果教程](
    https://www.chenweikang.top/?p=613)
* [解锁hdmi输出](
    https://blog.daliansky.net/Tutorial-Using-Hackintool-to-open-the-correct-pose-of-the-8th-generation-core-display-HDMI-or-DVI-output.html)
* [Deskmini310](
    https://github.com/liminghuang/asrock_deskmini310_hackintosh/tree/master/EFI)
* [U盘制作(安装hackintosh)](
    https://www.sqlsec.com/2018/08/clover.html)
* [解决无线网络和蓝牙](
    https://www.cnblogs.com/SemiconductorKING/p/7702410.html)

