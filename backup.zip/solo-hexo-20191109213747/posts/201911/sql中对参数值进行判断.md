title: sql中对参数值进行判断
date: '2019-11-09 10:49:55'
updated: '2019-11-09 10:49:55'
tags: [mysql语法]
permalink: /articles/2019/11/09/1573267795072.html
---
![](https://img.hacpai.com/bing/20180322.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

通常我们在进行web项目开发时，对参数的判断会放在mybatis里面进行判断，
诸如
```
<if test="type != null">
        type = #{type,jdbcType=VARCHAR},
 </if>
```但是在定制开发过程中，如遇上非java项目开发时，在没有框架性的处理时，这时就只能把逻辑放在sql中处理，在此对sql中参数判断的语法进行记录

SELECT ntu_time,Chinese_Name,field_cn,subject_cn,type as ntu_type
FROM table_name
where 1=1 
AND ( subject_cn = '${subject}' or '${subject}'='')
order by ntu_time  asc