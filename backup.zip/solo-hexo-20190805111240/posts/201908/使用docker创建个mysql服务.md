title: 使用 docker 创建个 mysql 服务
date: '2019-08-02 14:29:35'
updated: '2019-08-02 15:13:21'
tags: [docker, 容器, mysql, 数据库]
permalink: /docker,容器,mysql,数据库
---
![](https://img.hacpai.com/bing/20190425.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# docker 中下载 mysql

```

docker pull mysql

```

  

# 创建目录

创建几个目录后面挂载的时候要用到

```

mkdir -p ~/mysql/data ~/mysql/logs ~/mysql/conf

```

  

#启动

```

docker run \

-p 3306:3306 \

--name mysql \

-v $PWD/conf:/etc/mysql/conf.d \

-v $PWD/logs:/logs \

-v $PWD/data:/var/lib/mysql \

-e MYSQL_ROOT_PASSWORD=wangwang \

-d mysql

```

*  `-p 3306:3306`：将容器的 3306 端口映射到主机的 3306 端口。

*  `-v $PWD/conf:/etc/mysql/conf.d`：将主机当前目录下的 `conf/my.cnf` 挂载到容器的 `/etc/mysql/my.cnf`。

*  `-v $PWD/logs:/logs`：将主机当前目录下的 `logs` 目录挂载到容器的 `/logs`。

*  `-v $PWD/data:/var/lib/mysql` ：将主机当前目录下的data目录挂载到容器的 `/var/lib/mysql` 。

*  `-e MYSQL_ROOT_PASSWORD=wangwang`：初始化 root 用户的密码。

  

#进入容器

```

docker exec -it mysql bash

```

  

#登录mysql

```

mysql -u root -p

ALTER USER 'root'@'localhost' IDENTIFIED BY 'wangwang';

```

  

#添加远程登录用户

```

CREATE USER 'wang'@'%' IDENTIFIED WITH mysql_native_password BY 'wang!';

  

GRANT ALL PRIVILEGES ON *.* TO 'wnag'@'%' with grant option;

ALTER USER 'wang'@'%' IDENTIFIED BY 'wang';

```

  

# dockerfile 方式

```

FROM debian:jessie

  

# add our user and group first to make sure their IDs get assigned consistently, regardless of whatever dependencies get added

RUN groupadd -r mysql && useradd -r -g mysql mysql

  

# add gosu for easy step-down from root

ENV GOSU_VERSION 1.7

RUN set -x \

&& apt-get update && apt-get install -y --no-install-recommends ca-certificates wget && rm -rf /var/lib/apt/lists/* \

&& wget -O /usr/local/bin/gosu "https://github.com/tianon/gosu/releases/download/$GOSU_VERSION/gosu-$(dpkg --print-architecture)" \

&& wget -O /usr/local/bin/gosu.asc "https://github.com/tianon/gosu/releases/download/$GOSU_VERSION/gosu-$(dpkg --print-architecture).asc" \

&& export GNUPGHOME="$(mktemp -d)" \

&& gpg --keyserver ha.pool.sks-keyservers.net --recv-keys B42F6819007F00F88E364FD4036A9C25BF357DD4 \

&& gpg --batch --verify /usr/local/bin/gosu.asc /usr/local/bin/gosu \

&& rm -r "$GNUPGHOME" /usr/local/bin/gosu.asc \

&& chmod +x /usr/local/bin/gosu \

&& gosu nobody true \

&& apt-get purge -y --auto-remove ca-certificates wget

  

RUN mkdir /docker-entrypoint-initdb.d

  

# FATAL ERROR: please install the following Perl modules before executing /usr/local/mysql/scripts/mysql_install_db:

# File::Basename

# File::Copy

# Sys::Hostname

# Data::Dumper

RUN apt-get update && apt-get install -y perl pwgen --no-install-recommends && rm -rf /var/lib/apt/lists/*

  

# gpg: key 5072E1F5: public key "MySQL Release Engineering <mysql-build@oss.oracle.com>" imported

RUN apt-key adv --keyserver ha.pool.sks-keyservers.net --recv-keys A4A9406876FCBD3C456770C88C718D3B5072E1F5

  

ENV MYSQL_MAJOR 5.6

ENV MYSQL_VERSION 5.6.31-1debian8

  

RUN echo "deb http://repo.mysql.com/apt/debian/ jessie mysql-${MYSQL_MAJOR}" > /etc/apt/sources.list.d/mysql.list

  

# the "/var/lib/mysql" stuff here is because the mysql-server postinst doesn't have an explicit way to disable the mysql_install_db codepath besides having a database already "configured" (ie, stuff in /var/lib/mysql/mysql)

# also, we set debconf keys to make APT a little quieter

RUN { \

echo mysql-community-server mysql-community-server/data-dir select ''; \

echo mysql-community-server mysql-community-server/root-pass password ''; \

echo mysql-community-server mysql-community-server/re-root-pass password ''; \

echo mysql-community-server mysql-community-server/remove-test-db select false; \

} | debconf-set-selections \

&& apt-get update && apt-get install -y mysql-server="${MYSQL_VERSION}" && rm -rf /var/lib/apt/lists/* \

&& rm -rf /var/lib/mysql && mkdir -p /var/lib/mysql /var/run/mysqld \

&& chown -R mysql:mysql /var/lib/mysql /var/run/mysqld \

# ensure that /var/run/mysqld (used for socket and lock files) is writable regardless of the UID our mysqld instance ends up having at runtime

&& chmod 777 /var/run/mysqld

  

# comment out a few problematic configuration values

# don't reverse lookup hostnames, they are usually another container

RUN sed -Ei 's/^(bind-address|log)/#&/' /etc/mysql/my.cnf \

&& echo 'skip-host-cache\nskip-name-resolve' | awk '{ print } $1 == "[mysqld]" && c == 0 { c = 1; system("cat") }' /etc/mysql/my.cnf > /tmp/my.cnf \

&& mv /tmp/my.cnf /etc/mysql/my.cnf

  

VOLUME /var/lib/mysql

  

COPY docker-entrypoint.sh /usr/local/bin/

RUN ln -s usr/local/bin/docker-entrypoint.sh /entrypoint.sh # backwards compat

ENTRYPOINT ["docker-entrypoint.sh"]

  

EXPOSE 3306

CMD ["mysqld"]

```