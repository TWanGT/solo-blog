title: mongodb 启动事项(启动失败解决方案)
date: '2019-08-05 14:39:59'
updated: '2019-08-05 14:50:35'
tags: [mongodb, 数据库]
permalink: /articles/2019/08/05/1564987199205.html
---
# 启动脚本

* `-dbpath`: 数据文件存放地址

* `--logpath`: 日志文件存放地址(注意这个是文件不是地址)

* `-fork`: 后台启动(需要配合`--logpath`或者`--syslog`使用)

* `--auth`: 是否要进行用户认证

```shell

./mongod -dbpath="~/data" --logpath="~/log/mongo" -fork -auth &

```

## 带auth认证的

需要检验身份的, 一般都是用这个模式启动, 然后给不同场景分配不同的角色和权限

```

mongod --dbpath "/home/ciyun/mongodb3.2.10/data" --auth --logpath "/home/ciyun/mongodb3.2.10/log/mongodb.log" --logappend --fork &

```

## 不带auth认证的

不带 `auth` 启动比较少用到(不安全, 只要知道地址就能够登陆), 一般就用这个模式启动上去创建好角色然后就重启改为 `auth` 模式了

```shell

mongod --dbpath "/home/ciyun/mongodb3.2.10/data" --logpath "/home/ciyun/mongodb3.2.10/log/mongodb.log" --logappend --fork &

```

# 错误启动案例

## error number 1

```

$ about to fork child process, waiting until server is ready for connections.

forked process: 25374

ERROR: child process failed, exited with error number 1

```

`错误1` 一般是由于启动配置错误导致的, 检查下启动脚本中数据和日志的配置地址是否正确

## error number 100

`number 100` 出现的原因可能是由于异常终止服务导致的服务锁

> 解决方案:

> 1. 到 `data` 所在目录清楚掉 `.lock` 结尾的文件

> 2. 到 `log` 所在目录清楚掉多余的日志文件(有需要的话想备份旧日志)

> 3. 使用 `--repair` 模式启动, 该模式会生成一个启动日志可以再里面看具体启动失败的原因

> 命令示例: `./mongod --dbpath=~/data --logpath=!/log/mongo --repair` 地址改成对应的

> 4. 再尝试用正常的启动命令启动服务

## 其他错误处理

如果启动不了则取看是否有日志指明出错原因, 如果没有尝试用 `--repair` 模式启动然后看是否有可供参考的日志生成, 有错误原因后面的事就好吧了

一般常见的错误就那么几种

1. 启动配置有问题

2. 服务未停止重复启动

3. 端口已被占用

4. 系统资源不足以支持新服务启动

> 实在不行重新下载个然后把 `data` 下的文件拷到新的地址, 并用新的 `mongodb` 指向这个地址