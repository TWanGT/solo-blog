title: Freemarker 3种循环模式
date: '2019-07-30 11:03:08'
updated: '2019-07-30 11:03:08'
tags: [java, freemarker]
permalink: /articles/2019/07/30/1564455787984.html
---
# 1. map循环

举例:

```html

<#if vo.urlMap??>

    <#list vo.urlMap?keys as key>

        <li>

            <a  href="${vo.urlMap[key]!''}}">${key!''}</a>

        </li>

    </#list>

</#if>

```

*  `vo.urlMap?keys`: 将`map`中的key循环(类似`keySet`迭代器)

* 循环中通过`map[key]`来取的`key`对应的`value`

* 如果需要当前循环下标, 使用`循环对象_index`取即可, 如: `key_index`

# 2. list循环

举例:

```html

<#list vo.valueList as value>

    <td>${value!''}</td>

</#list>

```

# 3. 自定义次数循环

举例:

```html

<!-- 动态长度 -->

<#list 0..(nums?number)!0 as i>

    <td>${vo.valueList[i]!''}</td>

</#list>

  

<!-- 固定长度 -->

<#list 1..100 as i>

    <td>${vo.valueList[i]!''}</td>

</#list>

```

用于配合取出`list`中的元素(list长度有时少于预期, 所以自定义次数)

> 需要注意的是, 由于循环次数和`list`长度解耦了, 要小心数组越界,

> (可以通过默认值的方式避免)

> 如: `${(vo.valueList[i])!'无'}`

> 将前面整个用括号括起来会自动判定每一步是否为`null`