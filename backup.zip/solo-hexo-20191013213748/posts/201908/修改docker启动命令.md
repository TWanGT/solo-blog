title: 修改docker 启动命令
date: '2019-08-01 14:44:47'
updated: '2019-08-01 14:44:47'
tags: [docker, 容器]
permalink: /articles/2019/08/01/1564641887164.html
---
![](https://img.hacpai.com/bing/20180825.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

有时候需要修改 `容器` 的启动命令, 但是又不想把 `容器` 删除然后从 `镜像` 重新新建一个容器

## 使用update命令修改
例如: 创建容器时忘了添加参数 `--restart=always` ，当 Docker 重启时，容器未能自动启动
命令如下:
```
docker container update --restart=always 容器名字
```