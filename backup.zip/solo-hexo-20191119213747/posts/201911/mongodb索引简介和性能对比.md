title: mongodb 索引简介和性能对比
date: '2019-11-05 16:29:28'
updated: '2019-11-05 16:29:28'
tags: [mongodb, 索引, 性能]
permalink: /articles/2019/11/05/1572942568160.html
---
# mongodb 索引简介和性能对比
> 索引提升非常多的查询速度(换来的代价是插入和修改会耗时增加), 合理的利用索引可以提升系统性能, 具体什么时候该加索引本文不进行叙述(`原则: 查多改少的场景或者查询耗时敏感入库耗时不敏感时可以考虑`), 只提供加索引前后的对比以及如何给 `mongodb` 添加索引


## 环境
* 本集合大约有400多w的数据
* 只有主键索引(添加索引前)
![stats](https://img.hacpai.com/file/2019/11/image-996599d5.png)


## 耗时(添加索引前)
![添加索引前](https://img.hacpai.com/file/2019/11/image-66071bf8.png)


## 添加索引
![添加索引](https://img.hacpai.com/file/2019/11/image-d04fa715.png)
```
db.originalReport.ensureIndex({"reportKey":1})
```
> 数据量大可能要执行一段时间
### 索引添加完毕
![索引添加完毕](https://img.hacpai.com/file/2019/11/image-70d5436c.png)

## 耗时(添加索引后)
可以看到, 加了索引后就是秒查询了(没加索引前是全表扫描)~~
> mongodb 的语句优化器会自动判断查询的执行顺序, 不用像 `sql` 那样把命中效率高的字段排序到后面

![添加索引后](https://img.hacpai.com/file/2019/11/image-4dedd1ca.png)
