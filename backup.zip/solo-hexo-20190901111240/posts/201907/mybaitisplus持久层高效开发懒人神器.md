title: ' mybaitis-plus 持久层高效开发, 懒人神器'
date: '2019-07-30 11:00:55'
updated: '2019-07-30 11:00:55'
tags: [java, mybatis]
permalink: /articles/2019/07/30/1564455655383.html
---
# mybaitis-plus 持久层高效开发, 懒人神器

[toc]

mybatis-plus 可以非常方便快捷的帮我们处理数据数据库持久层的相关逻辑(单表查询基本都不用写sql和映射了), 提高开发效率

> 前提: 需要配合`mybatis`用

# 引入mybatis-plus的jar包

首先需要在`pom.xml`中加入`mybatis-plus`的包

```xml

<dependency>

<groupId>com.baomidou</groupId>

<artifactId>mybatis-plus-boot-starter</artifactId>

<version>3.0.6</version>

</dependency>

```

# 添加mybatis-plus配置

在配置文件中加入`mybatis-plus`的扫描配置

```properties

mybatis-plus.mapper-locations=classpath:/mapper/msql/*.xml

mybatis-plus.type-aliases-package=com.wang.mapper.mysql

```

  

# 添加mybatis-plus扩展功能

## 1. 公共字段自动填充

  

```java

  

package com.wang.cloud.store.common.conf.mybatisplus;

  
  

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;

import org.apache.ibatis.reflection.MetaObject;

import org.springframework.stereotype.Component;

  

import java.util.Date;

  

/**

* 配置公共字段自动填充功能 @TableField(..fill = FieldFill.INSERT)

*

*/

  

@Component

public  class  MetaObjectHandlerConfig  implements  MetaObjectHandler {

@Override

public  void  insertFill(MetaObject  metaObject) {

  

Object  createTime = getFieldValByName("createTime", metaObject);

Object  updateTime = getFieldValByName("updateTime", metaObject);

if (createTime == null)

setFieldValByName("createTime",new  Date(), metaObject);//mybatis-plus版本2.0.9+

if (updateTime == null)

setFieldValByName("updateTime",new  Date(), metaObject);//mybatis-plus版本2.0.9+

}

  

@Override

public  void  updateFill(MetaObject  metaObject) {

Object  updateTime = getFieldValByName("updateTime", metaObject);

if (updateTime == null) {

setFieldValByName("updateTime", new  Date(), metaObject);//mybatis-plus版本2.0.9+

}

}

}

  
  

```

  

## 2. 开启插件功能

```java

package com.wang.cloud.store.common.conf.mybatisplus;

  

import com.baomidou.mybatisplus.core.injector.ISqlInjector;

import com.baomidou.mybatisplus.extension.injector.LogicSqlInjector;

import com.baomidou.mybatisplus.extension.plugins.OptimisticLockerInterceptor;

import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;

import com.baomidou.mybatisplus.extension.plugins.PerformanceInterceptor;

import org.mybatis.spring.annotation.MapperScan;

import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;

import org.springframework.context.annotation.Profile;

  
  

@Configuration

@MapperScan("com.wang.cloud.store.mapper")//这个注解，作用相当于下面的@Bean MapperScannerConfigurer，2者配置1份即可

public  class  MybatisPlusConfig {

  
  

/**

* 分页插件

*/

@Bean

public  PaginationInterceptor  paginationInterceptor() {

return  new  PaginationInterceptor();

}

  
  

/**

* sql注入器 逻辑删除插件

* @return

*/

@Bean

public  ISqlInjector  iSqlInjector(){

return  new  LogicSqlInjector();

}

  
  

/**

* sql性能分析插件，输出sql语句及所需时间

* @return

*/

@Bean

@Profile({"dev","test"})// 设置 dev test 环境开启

public  PerformanceInterceptor  performanceInterceptor() {

return  new  PerformanceInterceptor();

}

  

/**

* 乐观锁插件

* @return

*/

@Bean

public  OptimisticLockerInterceptor  optimisticLockerInterceptor(){

return  new  OptimisticLockerInterceptor();

}

  
  

}

```