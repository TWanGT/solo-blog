title: 使用 openssl 创建站点认证证书
date: '2019-08-02 11:14:36'
updated: '2019-08-02 11:14:36'
tags: [openssl, 安全, 证书]
permalink: /articles/2019/08/02/1564715676396.html
---
可以使用免费的证书认证(有独立域名的情况下), 也可以使用 `openssl` 自行签发证书。

> 本文主要是给我的 `docker` 私有仓库用户上 `https` 所以自行签发证书( 默认 `docker client` 的通信是用的 `https` 但是目前我的本地服务器(在本地虚拟机中)是用的 `http` 导致通信不畅, 也可修改 `docker` 的配置让其使用 `http` 但是我想在 `IDEA` 中也用上, 所以还是配个 `https` 比较稳妥, 顺便学习下 `openssl`


---

> 参考文章:
http://xstarcd.github.io/wiki/sysadmin/openssl_genrsa_req_sign.html

# 简介
![制作证书步骤](http://xstarcd.github.io/wiki/img/https_Certificate_rq_sign.png)
一般情况下，制作证书要经过几个步骤，如上图所示。

* 首先用openssl genrsa生成一个私钥
* 然后用openssl req生成一个签署请求
* 最后把请求交给CA，CA签署后就成为该CA认证的证书

如果生成签署请求时加上-x509参数，那么就直接生成一个self-signed的证书，即自己充当CA认证自己。

如果您只是想做一张测试用的电子证书或不想花钱去找个 CA 签署，您可以造一张自签 (Self-signed) 的电子证书。当然这类电子证书没有任何保证，大部份软件偶到这证书会发出警告，甚至不接收这类证书。使用自签名(self-signed)的证书，它的主要目的不是防伪，而是使用户和系统之间能够进行SSL通信，保证密码等个人信息传输时的安全。

这里先说下证书相关的几个名词：

* `RSA` : 私钥能解密用证书公钥加密后的信息。通常以 `.key` 为后缀，表示私钥也称作密钥。是需要管理员小心保管，不能泄露的。
*` CSR(Certificate Signing Request)` : 包含了公钥和名字信息。通常以 `.csr` 为后缀，是网站向 `CA` 发起认证请求的文件，是中间文件。
* `crt` : 证书通常以 `.crt` 为后缀，表示证书文件。
* `CA(Certifying Authority)` : 表示证书权威机构，它的职责是证明公钥属于个人、公司或其他的组织。

# 脑图展示
大致的内容我话了个脑图, 大概就 8 个步骤
![openssl自行签发证书](https://img.hacpai.com/file/2019/08/image-aaec2009.png)


# 具体操作
## CA 证书部分
### 1. 创建私钥
命令如下:
```
openssl genrsa -out "root-ca.key" 4096
```
![1. 创建私钥](https://img.hacpai.com/file/2019/08/image-92d49803.png)


### 2. 用私钥创建 CA 证书
```
openssl req \
          -new -key "root-ca.key" \
          -out "root-ca.csr" -sha256 \
          -subj '/C=CN/ST=GuangDong/L=ShenZhen/O=Your Company Name/CN=WanG Docker Registry CA'
```
![用私钥创建 CA 证书](https://img.hacpai.com/file/2019/08/image-1f644eb1.png)


### 3. 配置 CA 证书
#### a. 创建 `oot-ca.cnf` 文件
使用 `vi` 或 `vim` 打开文件(没有权限的话命令最前面加上 `sudo` )
```
vi root-ca.cnf
```

#### b. 保存配置
在 `vim` 中输入以下内容(`:wq`)保存
```
[root_ca]
basicConstraints = critical,CA:TRUE,pathlen:1
keyUsage = critical, nonRepudiation, cRLSign, keyCertSign
subjectKeyIdentifier=hash
```
![配置 CA 证书](https://img.hacpai.com/file/2019/08/image-98909ab7.png)


### 4. 签发 CA 证书
使用刚才生成的 `秘钥` 和 `配置` 签发 `CA证书`
```
openssl x509 -req  -days 3650  -in "root-ca.csr" \
               -signkey "root-ca.key" -sha256 -out "root-ca.crt" \
               -extfile "root-ca.cnf" -extensions \
               root_ca
```
![签发 CA 证书](https://img.hacpai.com/file/2019/08/image-c32e40a2.png)


## ssl 站点证书
### 5. 生成站点的 ssl 私钥
```
openssl genrsa -out "docker.wang.key" 4096
```
![生成站点的 ssl 私钥](https://img.hacpai.com/file/2019/08/image-b39cdb3d.png)

### 6. 用私钥创建 ssl 证书
```
openssl req -new -key "docker.wang.key" -out "site.csr" -sha256 \
          -subj '/C=CN/ST=GuangDong/L=ShenZhen/O=WanG/CN=docker.wang'
```
![用私钥创建 ssl 证书](https://img.hacpai.com/file/2019/08/image-556d2352.png)

### 7. 配置 ssl 证书
#### a. 创建 `site.cnf ` 文件
```
vi site.cnf
```

#### b. 保存配置
```
[server]
authorityKeyIdentifier=keyid,issuer
basicConstraints = critical,CA:FALSE
extendedKeyUsage=serverAuth
keyUsage = critical, digitalSignature, keyEncipherment
subjectAltName = DNS:docker.wang, IP:127.0.0.1
subjectKeyIdentifier=hash
```
![配置 ssl 证书](https://img.hacpai.com/file/2019/08/image-b17e1efa.png)

### 8. 签发 ssl 证书
```
openssl x509 -req -days 750 -in "site.csr" -sha256 \
    -CA "root-ca.crt" -CAkey "root-ca.key"  -CAcreateserial \
    -out "docker.wang.crt" -extfile "site.cnf" -extensions server
```

![签发 ssl 证书](https://img.hacpai.com/file/2019/08/image-19d8920e.png)
