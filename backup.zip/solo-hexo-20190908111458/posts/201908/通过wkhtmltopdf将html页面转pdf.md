title: 通过wkhtmltopdf将html页面转pdf
date: '2019-08-14 14:23:20'
updated: '2019-08-14 14:23:20'
tags: [linux, pdf, ubuntu]
permalink: /articles/2019/08/14/1565763800344.html
---
# 通过wkhtmltopdf将html页面转pdf
  

## 安装wkhtmltopdf

> 本文的安装环境是 `ubuntu`

  

### 1. 下载对应系统的软件

官网各版本[下载地址](https://wkhtmltopdf.org/downloads.html)

> 如果和我一样系统(`ubuntu18.04`)可以下载[这个](https://downloads.wkhtmltopdf.org/0.12/0.12.5/wkhtmltox_0.12.5-1.bionic_amd64.deb)

  

### 2. 安装

>  `deb` 结尾的为 `debian`的 `package`文件(`ubuntu` 是基于 `debian`的)

安装命令:

```

dpkg -I 安装包

```

  

## 安装中可能出现的问题

安装过程中可能出现缺少xxx依赖包, 导致安装终止的情况

例如:

```

下列软件包有未满足的依赖关系：

wkhtmltox : 依赖: libpng12-0 但无法安装它

依赖: xfonts-75dpi 但是它还没有被安装

```

  

这时候只需要缺少什么安装什么就好了(安装好依赖后重新安装 `wkhtmltopdf`)

```shell

sudo apt install 缺少xxx

```

  

## 使用wkhtmltopdf

### 1. 确认是否正常安装

安装后尝试使用命令确认安装情况

```

wkhtmltopdf -v

```

如果正确输出版本等信息则为OK

> 如果没有的话可以去 `/bin` 目录尝试下执行这个命令

  

### 2. 将html文件转为pdf

> wkhtmltopdf [这里可以接全局option]  <html文件路径> <输出的pdf文件路径>

```

wkhtmltopdf "/home/wang/test.html" /home/wang/test.pdf

```

  

### 3. 将网址转为pdf

> wkhtmltopdf [这里可以接全局option]  <url地址> <输出的pdf文件路径>

> 网址最好用`引号`括起来, 如果携带多个参数没有引号可能导致命令错乱

```

wkhtmltopdf "https://www.jd.com" /home/wang/jj.pdf

```