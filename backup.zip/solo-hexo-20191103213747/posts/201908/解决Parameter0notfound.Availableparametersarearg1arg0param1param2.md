title: 解决  Parameter '0' not found. Available parameters are [arg1, arg0, param1,
  param2]
date: '2019-08-09 16:14:02'
updated: '2019-08-09 16:14:02'
tags: [mybatis-plus, java, 数据库]
permalink: /articles/2019/08/09/1565338441885.html
---
# 解决  Parameter '0' not found. Available parameters are [arg1, arg0, param1, param2]

这个问题比较尴尬, 是我在将一个项目的数据库连接工具转为 `mybatis-plus` 的时候遇到的, 问题原因其实是新版的 `mybatis-plus` 的 `xml` 解析规则修改了

## 解决方案
要解决这个问题其实很简单, 只不过如果 `xml` 配置多的话可能会比较繁琐

> 只要将 `#{0}` 这种换成 `#{arg0}`

### 修改前: 
![image.png](https://img.hacpai.com/file/2019/08/image-2a291bf5.png)
### 修改后: 
![image.png](https://img.hacpai.com/file/2019/08/image-ce4167af.png)

> 有个小技巧:
> 你用正则全文件目录搜索: `\{\d*\}` 的位置, 然后就能比较快的改动了