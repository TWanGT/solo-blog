title: rocketMQ 概念介绍
date: '2019-07-30 11:05:29'
updated: '2019-07-30 11:05:29'
tags: [rocketMQ, 消息队列, 架构]
permalink: /articles/2019/07/30/1564455929020.html
---
# rocketMQ 概念介绍 

## 模型概念

* `Topic`: 是用于存储逻辑的地址的

* `Consumer Group`: 是代表两个Consumer可共享相互之间的订阅

*  `Message Queue`: 消息队列

* `CommitLog`: 是消息主体以及元数据的存储主体(也可在`Consume Queue`数据丢失时用于数据恢复)

* `Consume Queue`: 是一个消息的逻辑队列，存储了这个Queue在CommitLog中的起始offset，log大小和MessageTag的hashCode。每个Topic下的每个Queue都有一个对应的ConsumerQueue文件，例如Topic中有三个队列，每个队列中的消息索引都会有一个编号，编号从0开始，往上递增。并由此一个位点offset的概念，有了这个概念，就可以对Consumer端的消费情况进行队列定义。

* `Message ID`: MQ给每个消息分配的一个唯一id

  

## 组件概念

* `Producer`: 是消息的发送者

* `Consumer`: 是消息订阅者(消费者)

* `Broker`: 是实际存储消息的数据节点

* `Nameserver`: 则是服务发现节点

  

### 消息发送

`Producer` 请求 `Nameserver` 获取指定的 `Topic` 所在的 `Broker`(路由地址, 队列信息(`Message Queue`)等), 然后讲消息发送过去

  

### 消息消费

`Consumer` 请求 `Nameserver` 获取指定的 `Topic` 所在的 `Broker`(路由地址, 队列信息(`Message Queue`)等), 然后获取消息

  

消息消费分两种模式:

*  `pull`: `Consumer`定时拉取消息

* `push`: 消息队列主动往存活的`Consumer`推送消息

  

## 注意事项

### 1. 重复消息

由于各种原因, 可能会造成消息重复消费, 所以在设计的时候要保证业务的`幂等性`或者通过记录`消息id`将消息去重处理

  

### 2. 如何重新消费消息

可能有各种原因导致需要将消息重复消费一遍(上次消费业务没正确执行)

1. 在控制台通过`Message ID`查询指定的消息, 然后点击`resend message`按钮

2. 将`offset`修改到前面的位置(`offset`会重新向后偏移, 并重新消费一遍消息)