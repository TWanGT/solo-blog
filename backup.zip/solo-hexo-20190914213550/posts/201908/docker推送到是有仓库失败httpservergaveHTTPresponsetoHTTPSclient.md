title: 'docker推送到是有仓库失败(http: server gave HTTP response to HTTPS client)'
date: '2019-08-01 16:12:49'
updated: '2019-08-02 11:46:43'
tags: [docker, 容器]
permalink: /articles/2019/08/01/1564647169510.html
---
# docker推送到是有仓库失败(http)

本地搭建了一个私有仓库, 但是当推送的时候发现无法推送成功, `http: server gave HTTP response to HTTPS client`

原因是推送是 `https`的, 但是服务器是 `http` 的导致通信失败

```

wang@wang-Parallels-Virtual-Platform:~$ docker push 192.168.1.97:5000/nginx

The push refers to repository [192.168.1.97:5000/nginx]

Get https://192.168.1.97:5000/v2/: http: server gave HTTP response to HTTPS client

```

## 修改 docker 配置

在 `/etc/docker/` 目录下，创建 `daemon.json` 文件

```

sudo vi /etc/docker/daemon.json

```

  

> 将对应的 `ip` 和 `端口` 改为自己的

```

{

"insecure-registries": [

"wang:5000"

]

}

```

  

> 这里的 `wang` 是我在 `host` 中改的本地映射

> 输入命令: `sudo vi /etc/hosts`

> 加入后面的内容: `127.0.0.1 wang`

  

## 重启

```

sudo systemctl restart docker

```

![image.png](https://img.hacpai.com/file/2019/08/image-d2d5ec54.png)


## 再次尝试推送
注意: 推送需要 `images` 中有同名的 `tag`
如果没有的话使用 `docker tag` 命令重命名一个
操作如下图
![再次尝试推送](https://img.hacpai.com/file/2019/08/image-dcc08a32.png)


## 高级版解决方案
服务器配置成 `https` 的
传送门: http://twangt.wang:8080/articles/2019/08/02/1564715676396.html

