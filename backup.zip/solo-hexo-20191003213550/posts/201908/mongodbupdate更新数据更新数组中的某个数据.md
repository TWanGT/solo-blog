title: mongodb update 更新数据,更新数组中的某个数据
date: '2019-08-01 14:00:09'
updated: '2019-08-02 11:25:57'
tags: [mongodb, 数据库]
permalink: /articles/2019/08/01/1564639209892.html
---

# 应用例子
```mongodb
db.dbName.update(
   {"items.itemValue":"null"},
   {$set:{'items.2.itemValue':'我被更新了'}},
   {multi:false}
 )
```
以上语句只会修改第一条发现的文档，如果你要修改多条相同的文档，则需要设置 `multi` 参数为 `true`。
`items.2.itemValue` 意思是更新`items`数组中的第三个元素(起始坐标为0)下的`itemValue`

  
![更新示例图](https://img.hacpai.com/file/2019/08/20181226114757315-f0cf5f84.png)



# update() 方法解释
> `update() `方法用于更新已存在的文档

## 语法格式
```mongodb
db.collection.update(
   <query>,
   <update>,
   {
     upsert: <boolean>,
     multi: <boolean>,
     writeConcern: <document>
   })
```

## 参数说明：
* query : update的查询条件，类似sql update查询内where后面的。
* update : update的对象和一些更新的操作符（如$,$inc...）等，也可以理解为sql update查询内set后面的
* upsert : 可选，这个参数的意思是，如果不存在update的记录，是否插入* objNew,true为插入，默认是false，不插入。
* multi : 可选，mongodb 默认是false,只更新找到的第一条记录，如果这个参数为true,就把按条件查出来多条记录全部更新。
* writeConcern :可选，抛出异常的级别。
