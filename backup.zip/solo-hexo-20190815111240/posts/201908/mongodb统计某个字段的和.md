title: mongodb 统计某个字段的和
date: '2019-08-01 13:58:20'
updated: '2019-08-01 13:58:20'
tags: [mongodb, 数据库]
permalink: /articles/2019/08/01/1564639100757.html
---
## 场景
`mongodb` 作为 `noSQL` 的文档型数据库, 里面存储的内容一般都是一个结构化的 `json` 格式文档, 所以导致部分统计可能没有直接写个 `sql` 方便, 但是 `mongodb` 本身提供了很多强大的查询功能, 使用得当的话可以获得同样的效果

## mongodb 原生的统计方式
思路: 我们可以使用 `$group` 来聚合统计
```
db.yourCollection.aggregate( [
   {
     $group: {
        _id: null,
        total: { $sum: "$discountMoney" }
     }
   }
] );
```

> 这种方法能够直接统计自己指定字段的和, 但是有个局限性, 如果字段类型不全为数字类型, 则统计数会有误(例如字段类型全为`string`的话直接为0)

## 特殊统计方式
由于我这次遇到场景是需要统计非数字类型的和(实际上是将数值存成了`string`), 所以上面的方法没正确统计出来
搜索了很多资料大致思路是用 `$project` 将字段改成数值类型, 或者将数值插入个新字段然后再统计
感觉都太麻烦了, 我只是临时想要知道一下某几个字段之和

后来偶然看到一个用 `js` 循环将字段改成数值重新保存数据的方法, 我就想我都直接循环全部数据量, 循环过程中不就可以吧数据统计出来吗, 于是有了下面的方式

思路: 查询所有需要统计的文档, 通过循环将需要计算的字段转成数字并累加到 `计数变量` 中, 最后输出 `计数变量`
```

//  统计数量(字符串类型)
var sTime = ISODate("2019-06-28 00:00:00.000Z");
var eTime = ISODate("2019-06-28 23:59:59.000Z");
var payPrice = 0;
var discount = 0;
var orderPrice = 0;   
db.yourCollection.find({"orderTime":{$gte:sTime, $lt:eTime}}).forEach(
  function(x) {
    var temp1 = Number(x.payMoney) ;
    var temp2 = Number(x.discountMoney) ;
    var temp3 = Number(x.orderMoney) ;
    payPrice = payPrice + temp1;
      discount = discount + temp2;
      orderPrice = orderPrice + temp3;
  })
print(payPrice);
print(discount);
print(orderPrice);

```