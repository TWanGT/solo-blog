title: 开放docker engin 远程端口
date: '2019-08-01 14:42:27'
updated: '2019-08-01 14:42:27'
tags: [docker, 容器]
permalink: /articles/2019/08/01/1564641747778.html
---
![](https://img.hacpai.com/bing/20180707.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


## 修改配置
 ```
sudo vi /lib/systemd/system/docker.service
```

将原本的 `ExecStart` 注释, 并加入下面那行
```
# ExecStart=/usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock
ExecStart=/usr/bin/dockerd -H unix:///var/run/docker.sock -H tcp://0.0.0.0:2375
```

## 重新启动
重新加载 `daemon`
```
sudo systemctl daemon-reload
```

重新启动服务
```
sudo service docker restart
```